The BLOSUM and PAM matrices in this directory were obtained from NCBI
(ftp://ftp.ncbi.nih.gov/blast/matrices/).

All other matrices were obtained from the primary literature, as indicated in
the header of each file.
