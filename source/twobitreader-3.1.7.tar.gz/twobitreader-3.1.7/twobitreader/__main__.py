from twobitreader import cmdline_reader

cmdline_reader()
